package glacialExpedition.models.mission;

import glacialExpedition.models.explorers.Explorer;
import glacialExpedition.models.states.State;
import glacialExpedition.models.suitcases.Carton;
import glacialExpedition.models.suitcases.Suitcase;

import java.util.Collection;

public class MissionImpl implements Mission {


    @Override
    public void explore(State state, Collection<Explorer> explorers) {

        for (Explorer explorer : explorers) {
            Suitcase suitcase = explorer.getSuitcase();
            Collection<String> exhibits = suitcase.getExhibits();
            while (explorer.canSearch()) {
                for (String exhibit : state.getExhibits()) {
                    explorer.search();
                    exhibits.add(exhibit);
                }

                for (String exhibit : exhibits) {
                    state.getExhibits().remove(exhibit);
                }

            }
        }

    }

}
