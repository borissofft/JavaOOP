package CounterStriker.models.field;

import CounterStriker.models.players.Player;

import java.util.Collection;

public class FieldImpl implements Field {

    @Override
    public String start(Collection<Player> players) {

        return null;
    }

}
