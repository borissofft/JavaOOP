package spaceStation.core;

import spaceStation.repositories.AstronautRepository;
import spaceStation.repositories.PlanetRepository;

public class ControllerImpl implements Controller {

    private AstronautRepository astronautRepository;
    private PlanetRepository planetRepository;

    public ControllerImpl() {
        this.astronautRepository = new AstronautRepository();
        this.planetRepository = new PlanetRepository();
    }

    @Override
    public String addAstronaut(String type, String astronautName) {
        return null;
    }

    @Override
    public String addPlanet(String planetName, String... items) {
        return null;
    }

    @Override
    public String retireAstronaut(String astronautName) {
        return null;
    }

    @Override
    public String explorePlanet(String planetName) {
        return null;
    }

    @Override
    public String report() {
        return null;
    }

}
