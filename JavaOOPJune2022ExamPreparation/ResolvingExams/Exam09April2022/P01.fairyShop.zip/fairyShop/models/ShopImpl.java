package fairyShop.models;

import java.util.Collection;

public class ShopImpl implements Shop {

    @Override
    public void craft(Present present, Helper helper) {

        Collection<Instrument> instruments = helper.getInstruments();

        while (helper.canWork()) {
            for (Instrument instrument : instruments) {

            }


        }

    }

}
