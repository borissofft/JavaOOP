package glacialExpedition.core;

public class ControllerImpl implements Controller {



    @Override
    public String addExplorer(String type, String explorerName) {
        return null;
    }

    @Override
    public String addState(String stateName, String... exhibits) {
        return null;
    }

    @Override
    public String retireExplorer(String explorerName) {
        return null;
    }

    @Override
    public String exploreState(String stateName) {
        return null;
    }

    @Override
    public String finalResult() {
        return null;
    }

}
