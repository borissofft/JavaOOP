package glacialExpedition.models.explorers;

public class GlacierExplorer extends BaseExplorer {

    private static final double ENERGY = 40.00;

    public GlacierExplorer(String name) {
        super(name, ENERGY);
    }

}
