package fairyShop.models;

import java.util.Collection;
import java.util.List;

public class ShopImpl implements Shop {

    private Present present;
    private Helper helper;

    public ShopImpl(Present present, Helper helper) {
        this.present = present;
        this.helper = helper;
    }

    @Override
    public void craft(Present present, Helper helper) {

        List<Instrument> instruments = (List<Instrument>) this.helper.getInstruments();
        Instrument instrument = null;
        if (!instruments.isEmpty()) {
            instrument = instruments.get(0);
        }

        while (instrument != null) {

            if (this.helper.canWork()) {
                if (!instrument.isBroken()) {
                    this.helper.work();
                    this.present.getCrafted();
                } else if (instruments.iterator().hasNext()) {
                    instrument = instruments.iterator().next();
                } else {
                    break;
                }
                if (present.isDone()) {
                    break;
                }
            } else {
                break;
            }

        }
    }

}
