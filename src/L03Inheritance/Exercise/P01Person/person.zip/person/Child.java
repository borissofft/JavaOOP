//package L03Inheritance.Exercise.P01Person.person;

package person;

public class Child extends Person{

    public Child(String name, int age) {
        super(name, age);
    }

}
