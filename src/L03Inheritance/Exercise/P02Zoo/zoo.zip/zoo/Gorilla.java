//package L03Inheritance.Exercise.P02Zoo.zoo;

package zoo;

public class Gorilla extends Mammal {

    public Gorilla(String name) {
        super(name);
    }

}
