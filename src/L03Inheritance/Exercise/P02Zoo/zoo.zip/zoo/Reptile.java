//package L03Inheritance.Exercise.P02Zoo.zoo;

package zoo;

public class Reptile extends Animal {

    public Reptile(String name) {
        super(name);
    }

}
