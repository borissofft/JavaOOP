//package L03Inheritance.Exercise.P02Zoo.zoo;

package zoo;

public class Mammal extends Animal{

    public Mammal(String name) {
        super(name);
    }

}
