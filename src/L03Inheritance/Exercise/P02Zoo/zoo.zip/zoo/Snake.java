//package L03Inheritance.Exercise.P02Zoo.zoo;

package zoo;

public class Snake extends Reptile {

    public Snake(String name) {
        super(name);
    }

}
