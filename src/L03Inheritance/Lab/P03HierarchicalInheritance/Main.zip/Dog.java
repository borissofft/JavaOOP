//package L03Inheritance.Lab.P03HierarchicalInheritance;

public class Dog extends Animal {

    public void bark() {
        System.out.println("barking…");
    }

}
