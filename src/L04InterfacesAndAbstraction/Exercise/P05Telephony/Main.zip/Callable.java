//package L04InterfacesAndAbstraction.Exercise.P05Telephony;

public interface Callable {

    public String call();

}
