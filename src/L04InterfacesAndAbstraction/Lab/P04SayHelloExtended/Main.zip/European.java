//package L04InterfacesAndAbstraction.Lab.P04SayHelloExtended;

public class European extends BasePerson {

    protected European(String name) {
        super(name);
    }

    @Override
    public String getName() {
        return super.getName();
    }

}
