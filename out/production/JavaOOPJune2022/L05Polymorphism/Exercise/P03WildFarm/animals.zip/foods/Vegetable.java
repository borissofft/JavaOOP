//package L05Polymorphism.Exercise.P03WildFarm.foods;

package foods;

public class Vegetable extends Food {

    public Vegetable(Integer quantity) {
        super(quantity);
    }

}
