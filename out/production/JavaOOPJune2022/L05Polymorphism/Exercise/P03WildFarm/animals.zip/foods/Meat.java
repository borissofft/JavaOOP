//package L05Polymorphism.Exercise.P03WildFarm.foods;

package foods;

public class Meat extends Food {

    public Meat(Integer quantity) {
        super(quantity);
    }

}
