//package L04InterfacesAndAbstraction.Exercise.P04FoodShortage;

public interface Person {

    String getName();

    int getAge();

}
