//package L04InterfacesAndAbstraction.Exercise.P04FoodShortage;

public interface Identifiable {

    String getId();

}
