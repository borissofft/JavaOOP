package military.interfaces;

public interface LieutenantGeneral {

    void addPrivate(Soldier p);

}
