package military.interfaces;

public interface SpecialisedSoldier {



}
