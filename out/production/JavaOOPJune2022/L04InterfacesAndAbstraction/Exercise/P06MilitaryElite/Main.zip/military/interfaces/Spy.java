package military.interfaces;

public interface Spy {



}
