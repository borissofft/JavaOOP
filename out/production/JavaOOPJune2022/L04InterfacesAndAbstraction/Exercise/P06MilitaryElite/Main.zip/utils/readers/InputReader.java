package utils.readers;

public interface InputReader {

    String readLine();

}
