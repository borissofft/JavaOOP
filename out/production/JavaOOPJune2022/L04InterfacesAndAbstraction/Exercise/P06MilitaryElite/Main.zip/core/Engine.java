package core;

public interface Engine {

    void run();

}
