//package L04InterfacesAndAbstraction.Exercise.P02MultipleImplementation;

public interface Identifiable {

    String getId();

}
