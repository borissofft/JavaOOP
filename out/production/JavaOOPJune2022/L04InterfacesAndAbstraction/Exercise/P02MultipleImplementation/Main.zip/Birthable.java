//package L04InterfacesAndAbstraction.Exercise.P02MultipleImplementation;

public interface Birthable {

    String getBirthDate();

}
