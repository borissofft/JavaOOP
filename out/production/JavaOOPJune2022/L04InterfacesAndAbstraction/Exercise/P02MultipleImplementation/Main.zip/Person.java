//package L04InterfacesAndAbstraction.Exercise.P02MultipleImplementation;

public interface Person {

    String getName();

    int getAge();

}
