//package L04InterfacesAndAbstraction.Exercise.P03BirthdayCelebrations;

public interface Identifiable {

    String getId();

}
