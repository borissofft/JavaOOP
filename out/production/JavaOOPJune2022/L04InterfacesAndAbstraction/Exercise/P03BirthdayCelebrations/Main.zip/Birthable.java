//package L04InterfacesAndAbstraction.Exercise.P03BirthdayCelebrations;

public interface Birthable {

    String getBirthDate();

}
