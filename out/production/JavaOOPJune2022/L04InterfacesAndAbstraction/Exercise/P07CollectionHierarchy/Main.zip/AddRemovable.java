//package L04InterfacesAndAbstraction.Exercise.P07CollectionHierarchy;

public interface AddRemovable extends Addable {

    String remove();

}
