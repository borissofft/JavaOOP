//package L04InterfacesAndAbstraction.Exercise.P07CollectionHierarchy;

public interface Addable {

    int add(String element);

}
