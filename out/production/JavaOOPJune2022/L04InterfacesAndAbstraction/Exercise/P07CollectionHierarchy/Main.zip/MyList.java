//package L04InterfacesAndAbstraction.Exercise.P07CollectionHierarchy;

public interface MyList extends AddRemovable {

    int getUsed();

}
