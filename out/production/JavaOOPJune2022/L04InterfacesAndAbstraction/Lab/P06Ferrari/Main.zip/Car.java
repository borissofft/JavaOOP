//package L04InterfacesAndAbstraction.Lab.P06Ferrari;

public interface Car {

    String brakes();

    String gas();

}
