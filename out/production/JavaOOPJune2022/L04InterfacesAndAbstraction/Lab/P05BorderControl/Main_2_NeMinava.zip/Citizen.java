//package L04InterfacesAndAbstraction.Lab.P05BorderControl;

public class Citizen extends IdentifiableImpl { // Може общото поле id да не се изнася в абстрактен клас и Citizen да имплементира Identifiable виж Main_1.zip

    private String name;
    private int age;


    public Citizen(String name, int age, String id) {
        super(id);
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return this.name;
    }

    public int getAge() {
        return this.age;
    }

}
