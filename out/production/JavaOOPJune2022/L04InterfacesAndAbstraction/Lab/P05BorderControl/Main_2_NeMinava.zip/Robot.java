//package L04InterfacesAndAbstraction.Lab.P05BorderControl;

public class Robot extends IdentifiableImpl { // Може общото поле id да не се изнася в абстрактен клас и Robot да имплементира Identifiable виж Main_1.zip

    private String model;

    public Robot(String model, String id) {
        super(id);
        this.model = model;
    }

    public String getModel() {
        return this.model;
    }

}
