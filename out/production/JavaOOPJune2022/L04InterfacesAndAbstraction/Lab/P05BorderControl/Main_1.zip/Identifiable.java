//package L04InterfacesAndAbstraction.Lab.P05BorderControl;

public interface Identifiable {

    String getId();

}
