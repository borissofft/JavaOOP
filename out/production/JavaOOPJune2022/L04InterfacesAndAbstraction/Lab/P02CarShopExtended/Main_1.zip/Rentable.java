//package L04InterfacesAndAbstraction.Lab.P02CarShopExtended;

public interface Rentable extends Car {

    Integer getMinRentDay();

    Double getPricePerDay();

}
