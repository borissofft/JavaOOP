package L01WorkingWithAbstraction.Exercise.P04TrafficLights;

public enum TrafficLight {

    RED,
    GREEN,
    YELLOW;

}
