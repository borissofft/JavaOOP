package L01WorkingWithAbstraction.Exercise.P01CardSuit;

public enum CardSuit {

    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES;

}
