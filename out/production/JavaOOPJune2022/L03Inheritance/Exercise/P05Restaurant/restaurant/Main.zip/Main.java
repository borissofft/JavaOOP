//package L03Inheritance.Exercise.P05Restaurant.restaurant;

public class Main {
    public static void main(String[] args) {



    }
}
