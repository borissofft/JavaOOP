//package L03Inheritance.Exercise.P04NeedForSpeed;

public class Motorcycle extends Vehicle {

    public Motorcycle(double fuel, int horsePower) {
        super(fuel, horsePower);
    }


}
