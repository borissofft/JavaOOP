//package L03Inheritance.Lab.P02MultipleInheritance;

public class Puppy extends Dog {

    public void weep() {
        System.out.println("weeping…");
    }

}
