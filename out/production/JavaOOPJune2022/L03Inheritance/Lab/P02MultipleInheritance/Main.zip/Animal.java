//package L03Inheritance.Lab.P02MultipleInheritance;

public class Animal {

    public void eat() {
        System.out.println("eating…");
    }

}
